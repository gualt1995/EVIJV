If you want to use Jurassic as source code in Unity, follow these steps:

1. Replase Jurassic.dll with the files inside the Jurassic folder
2. Put the gmcs.rsp and cmcs.rsp into the asset root folder, they contain -unsafe to enable unsafe code in unity.
3. Restart unity to adopt the unsafe setting
4. Now Jurassic should work as source code version